import { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { loginApi, getContractsApi, getProductsApi, registerContractApi } from '../api';
import { getThemeConfig } from '../theme';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [deptCode, setDeptCode] = useState('');
  const [contracts, setContracts] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);

  // 部門コードに基づくテーマ設定
  const tc = useMemo(() => getThemeConfig(deptCode), [deptCode]);

  const login = useCallback(async (account, password, code) => {
    setLoading(true);
    try {
      const res = await loginApi(account, password);
      if (res.success) {
        setUser(res.user);
        setDeptCode(code || '');
        const [contractsRes, productsRes] = await Promise.all([
          getContractsApi(res.user.id),
          getProductsApi(),
        ]);
        if (contractsRes.success) setContracts(contractsRes.contracts);
        if (productsRes.success) setProducts(productsRes.products);
        return true;
      }
    } finally {
      setLoading(false);
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setDeptCode('');
    setContracts([]);
    setProducts([]);
  }, []);

  const addContract = useCallback(async (contractData) => {
    setLoading(true);
    try {
      const res = await registerContractApi(contractData);
      if (res.success) {
        setContracts((prev) => [res.contract, ...prev]);
        return res.contract;
      }
    } finally {
      setLoading(false);
    }
    return null;
  }, []);

  const refreshContracts = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await getContractsApi(user.id);
      if (res.success) setContracts(res.contracts);
    } finally {
      setLoading(false);
    }
  }, [user]);

  const refreshProducts = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getProductsApi();
      if (res.success) setProducts(res.products);
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        deptCode,
        contracts,
        products,
        loading,
        tc,
        login,
        logout,
        addContract,
        refreshContracts,
        refreshProducts,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
