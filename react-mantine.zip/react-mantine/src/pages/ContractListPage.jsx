import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Box, Flex, Title, Text, Button, Table } from '@mantine/core';

export default function ContractListPage() {
  const navigate = useNavigate();
  const { user, contracts, loading, tc } = useApp();

  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);
  if (!user) return null;

  return (
    <Box mih="100vh" bg={tc.pageBg} p={24}>
      <Box maw={1200} mx="auto">
        <Flex justify="space-between" align="center" mb={24}>
          <Title order={3} display="inline-block" style={{ borderBottom: `3px solid ${tc.primary}`, paddingBottom: 4 }}>契約一覧</Title>
          <Button variant="outline" onClick={() => navigate('/personal')}>マイページへ戻る</Button>
        </Flex>

        {loading ? (
          <Text c="dimmed" ta="center" py={32}>読み込み中…</Text>
        ) : contracts.length === 0 ? (
          <Text c="dimmed" ta="center" py={32}>契約はまだありません。</Text>
        ) : (
          <Box bg="white" style={{ borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
            <Table highlightOnHover>
              <Table.Thead style={{ backgroundColor: tc.accentLighter }}>
                <Table.Tr>
                  <Table.Th fw={700}>顧客名</Table.Th>
                  <Table.Th fw={700}>契約名</Table.Th>
                  <Table.Th fw={700}>締結日</Table.Th>
                  <Table.Th fw={700}>契約時長</Table.Th>
                  <Table.Th fw={700}>詳細</Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {contracts.map((c) => (
                  <Table.Tr key={c.id}>
                    <Table.Td>{c.customerName}</Table.Td>
                    <Table.Td>{c.productName}</Table.Td>
                    <Table.Td>{c.signedAt}</Table.Td>
                    <Table.Td>{c.duration}</Table.Td>
                    <Table.Td>
                      <Button size="xs" style={{ backgroundColor: tc.primary, color: 'white' }}
                        onClick={() => navigate(`/contract-detail/${c.id}`)}>詳細</Button>
                    </Table.Td>
                  </Table.Tr>
                ))}
              </Table.Tbody>
            </Table>
          </Box>
        )}
      </Box>
    </Box>
  );
}
