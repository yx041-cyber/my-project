import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 設定リファレンス: https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    dedupe: ['react', 'react-dom'],
  },
})
