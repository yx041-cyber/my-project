import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useContractFlow } from '../../context/ContractFlowContext';
import FlowLayout from './FlowLayout';
import ArrowStepper from './ArrowStepper';
import { Box, Flex, Title, Text, Button, Table, Checkbox } from '@mantine/core';

export default function Input3() {
  const navigate = useNavigate();
  const { user, tc } = useApp();
  const { flowState, setConfirmedPersonalInfo, setConfirmedContractInfo } = useContractFlow();
  const [personalConfirmed, setPersonalConfirmed] = useState(false);
  const [contractConfirmed, setContractConfirmed] = useState(false);

  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);
  if (!user) return null;

  const { customerInfo, selectedProduct, selectedSubProduct, estimate } = flowState;
  const handleNext = () => { setConfirmedPersonalInfo(true); setConfirmedContractInfo(true); navigate('/contract-flow/input-4'); };

  const personalRows = [['お名前', customerInfo.name], ['性別', customerInfo.gender], ['生年月日', customerInfo.birthday],
    ['住所', customerInfo.address], ['電話番号', customerInfo.phone], ['メールアドレス', customerInfo.email]];
  const contractRows = [['選択商品', selectedProduct?.name], ['プラン', selectedSubProduct?.name],
    ['月額料金', `¥${estimate?.monthlyFee?.toLocaleString() || '-'}`], ['消費税', `¥${estimate?.tax?.toLocaleString() || '-'}`]];

  return (
    <FlowLayout title="最終確認" onBack={() => navigate('/contract-flow/input-1')} onNext={handleNext} nextLabel="契約を確定する" nextDisabled={!(personalConfirmed && contractConfirmed)}>
      <ArrowStepper activeIndex={2} primaryColor={tc.primary} />
      <Flex justify="space-between" align="center" mb={8}>
        <Title order={4}>顧客情報の確認</Title>
        <Button size="xs" variant="subtle" c={tc.primary} onClick={() => navigate('/contract-flow/input-1')}>✏️ 修正する</Button>
      </Flex>
      <Box mb={12} style={{ border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden' }}>
        <Table verticalSpacing="xs">
          <Table.Tbody>
            {personalRows.map(([l, v]) => (
              <Table.Tr key={l}>
                <Table.Td w="40%" fw={500} style={{ backgroundColor: '#f9fafb' }}>{l}</Table.Td>
                <Table.Td>{v || '-'}</Table.Td>
              </Table.Tr>
            ))}
          </Table.Tbody>
        </Table>
      </Box>
      <Checkbox label="上記の顧客情報に誤りがないことを確認しました" checked={personalConfirmed}
        onChange={(e) => setPersonalConfirmed(e.currentTarget.checked)} mb={20} />

      <Title order={4} mb={8}>契約内容の確認</Title>
      <Box mb={12} style={{ border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden' }}>
        <Table verticalSpacing="xs">
          <Table.Tbody>
            {contractRows.map(([l, v]) => (
              <Table.Tr key={l}>
                <Table.Td w="40%" fw={500} style={{ backgroundColor: '#f9fafb' }}>{l}</Table.Td>
                <Table.Td>{v || '-'}</Table.Td>
              </Table.Tr>
            ))}
            <Table.Tr>
              <Table.Td fw={700}>月額合計（税込）</Table.Td>
              <Table.Td fw={700} style={{ color: tc.primary, fontSize: '1.125rem' }}>¥{estimate?.total?.toLocaleString() || '-'}</Table.Td>
            </Table.Tr>
          </Table.Tbody>
        </Table>
      </Box>
      <Checkbox label="上記の契約内容に誤りがないことを確認しました" checked={contractConfirmed}
        onChange={(e) => setContractConfirmed(e.currentTarget.checked)} mb={20} />

      <Box p={12} style={{ backgroundColor: '#fff7ed', border: '1px solid #fb923c', borderRadius: 6 }}>
        <Text size="sm" style={{ color: '#9a3412' }}>
          <strong>最終確認：</strong>「契約を確定する」ボタンを押すと契約が確定します。すべての内容をご確認のうえ、お進みください。
        </Text>
      </Box>
    </FlowLayout>
  );
}
