import { Box, Flex, Title, Text, Button } from '@mantine/core';
import { useApp } from '../../context/AppContext';

export default function FlowLayout({ title, children, onBack, onNext, nextLabel, nextDisabled, hideActions }) {
  const { tc } = useApp();

  return (
    <Box mih="100vh" bg={tc.pageBg} p="md">
      <Box maw={1000} mx="auto">
        {/* ヘッダー */}
        <Flex justify="space-between" align="center" mb={12}>
          <Title order={3} display="inline-block" style={{ borderBottom: `3px solid ${tc.primary}`, paddingBottom: 4 }}>{title}</Title>
        </Flex>

        {/* コンテンツ */}
        <Box bg="white" p={20} mb="md" style={{ border: '1px solid #e5e7eb', borderRadius: 12 }}>
          {children}
        </Box>

        {/* アクションボタン */}
        {!hideActions && (
          <Flex justify="space-between">
            <Button variant="outline" size="lg" onClick={onBack}>戻る</Button>
            <Button size="lg" style={{ backgroundColor: tc.primary, color: 'white' }} onClick={onNext} disabled={nextDisabled}>
              {nextLabel || '次へ'}
            </Button>
          </Flex>
        )}
      </Box>
    </Box>
  );
}
