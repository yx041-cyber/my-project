import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { useContractFlow } from '../context/ContractFlowContext';
import { Box, Flex, Title, Text, Button, SimpleGrid, Stack, Badge } from '@mantine/core';

/**
 * マイページ（個人ページ）
 * ログイン後のメイン画面。サイドバーにユーザー情報、メインエリアに商品一覧を表示。
 * 商品を選択すると契約フロー（見積りページ）へ遷移する。
 */
export default function PersonalPage() {
  const navigate = useNavigate();
  // user: ログインユーザー情報、products: 商品一覧、tc: テーマカラー設定
  const { user, products, loading, logout, tc } = useApp();
  // resetFlow: 契約フローの状態を初期化、setSelectedProduct: 選択商品を Context に保存
  const { resetFlow, setSelectedProduct } = useContractFlow();

  // 未ログインならログインページへリダイレクト
  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);
  if (!user) return null;

  // ログアウト処理：セッションをクリアしてログインページへ
  const handleLogout = () => { logout(); navigate('/login', { replace: true }); };
  // 商品クリック：フロー初期化 → 商品を Context に保存 → 見積りページへ遷移
  const handleProductClick = (product) => { resetFlow(); setSelectedProduct(product); navigate('/contract-flow/product-intro'); };

  return (
    <Flex mih="100vh" bg={tc.pageBg}>

      {/* ===== サイドバー ===== */}
      <Stack w={220} miw={200} bg={tc.sidebarBg} gap={0} style={{ borderRight: '1px solid #e5e7eb' }}>
        {/* サイドバーヘッダー */}
        <Box bg={tc.headerBg} py={12} px={16}>
          <Text size="sm" fw={600} c={tc.headerText}>ユーザー情報</Text>
        </Box>
        {/* ユーザー情報表示（名前・役割・メール） */}
        <Box p="md">
          <Text fw={700}>{user.name}</Text>
          <Badge mt={4} style={{ backgroundColor: tc.accentLight, color: tc.sidebarText }}>{user.role}</Badge>
          <Text size="sm" c="dimmed" mt={8}>{user.email}</Text>
        </Box>
        {/* ログアウトボタン（サイドバー最下部に配置） */}
        <Box mt="auto" p={8} style={{ borderTop: '1px solid #e5e7eb' }}>
          <Button w="100%" variant="subtle" onClick={handleLogout} color="gray">ログアウト</Button>
        </Box>
      </Stack>

      {/* ===== メインコンテンツ ===== */}
      <Box flex={1} p={24} maw={1280} mx="auto">
        {/* ページタイトル（テーマカラーの下線付き） */}
        <Title order={3} mb={4} display="inline-block" style={{ borderBottom: `3px solid ${tc.primary}`, paddingBottom: 4 }}>マイページ</Title>
        <Text c="dimmed" mt={8} mb={24}>お客様への契約案内にご利用ください。商品を選択して新規契約を開始できます。</Text>

        {/* 契約一覧ページへの遷移ボタン */}
        <Button size="lg" mb={24} style={{ backgroundColor: tc.primary, color: 'white' }} onClick={() => navigate('/contracts')}>
          契約一覧
        </Button>

        {/* 商品一覧（2列グリッド）：API から取得した商品をカード形式で表示 */}
        <Title order={4} mb={16}>商品紹介</Title>
        {loading ? <Text c="dimmed">読み込み中…</Text> : (
          <SimpleGrid cols={2} spacing="md">
            {products.map((product) => (
              // 商品カード：クリックで契約フローへ遷移
              <Box
                key={product.id}
                bg="white"
                p={20}
                ta="center"
                className="card-hover"
                style={{ border: '1px solid #e5e7eb', borderRadius: 12, cursor: 'pointer' }}
                onClick={() => handleProductClick(product)}
              >
                <Text fz={30}>{product.icon}</Text>
                <Text fw={700} mt={8}>{product.name}</Text>
                <Text size="sm" c="dimmed" mt={4} ta="left">{product.description}</Text>
                {/* 新規契約ボタン（stopPropagation でカード全体のクリックと重複発火を防止） */}
                <Button mt={12} size="sm" style={{ backgroundColor: tc.primary, color: 'white' }}
                  onClick={(e) => { e.stopPropagation(); handleProductClick(product); }}>
                  新規契約
                </Button>
              </Box>
            ))}
          </SimpleGrid>
        )}
      </Box>
    </Flex>
  );
}
