import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { getContractDetailApi } from '../api';
import { Box, Flex, Title, Text, Button, Table } from '@mantine/core';

export default function ContractDetailPage() {
  const navigate = useNavigate();
  const { contractId } = useParams();
  const { user, tc } = useApp();
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/login', { replace: true }); return; }
    const fetchDetail = async () => {
      setLoading(true);
      const res = await getContractDetailApi(contractId);
      if (res.success && res.contract) setContract(res.contract);
      setLoading(false);
    };
    fetchDetail();
  }, [user, contractId, navigate]);

  if (!user) return null;

  const sections = contract ? [
    { heading: '顧客情報', rows: [
      ['お名前', contract.customerName], ['生年月日', contract.customerBirthday],
      ['性別', contract.customerGender], ['住所', contract.customerAddress],
      ['電話番号', contract.customerPhone], ['メールアドレス', contract.customerEmail],
    ]},
    { heading: '契約情報', rows: [
      ['契約名', contract.productName], ['プラン', contract.subProductName],
      ['締結日', contract.signedAt], ['契約期間', contract.duration],
      ['契約終了日', contract.endDate], ['月額料金', `¥${contract.monthlyFee?.toLocaleString()}`],
      ['状態', contract.status], ['他社契約有無', contract.hasOtherContract ? 'あり' : 'なし'],
    ]},
  ] : [];

  return (
    <Box mih="100vh" bg={tc.pageBg} p={24}>
      <Box maw={900} mx="auto">
        <Flex justify="space-between" align="center" mb={24}>
          <Title order={3} display="inline-block" style={{ borderBottom: `3px solid ${tc.primary}`, paddingBottom: 4 }}>契約詳細</Title>
          <Button variant="outline" onClick={() => navigate('/contracts')}>契約一覧へ戻る</Button>
        </Flex>

        {loading ? (
          <Text c="dimmed" ta="center" py={32}>読み込み中…</Text>
        ) : !contract ? (
          <Text c="dimmed" ta="center" py={32}>契約が見つかりません。</Text>
        ) : (
          <Box bg="white" style={{ borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
            {sections.map((section) => (
              <Box key={section.heading}>
                <Box bg={tc.accentLighter} px={16} py={8}>
                  <Text fw={700} c={tc.primary}>{section.heading}</Text>
                </Box>
                <Table highlightOnHover>
                  <Table.Tbody>
                    {section.rows.map(([label, value]) => (
                      <Table.Tr key={label}>
                        <Table.Td w="35%" fw={500} style={{ backgroundColor: '#f9fafb' }}>{label}</Table.Td>
                        <Table.Td>{value}</Table.Td>
                      </Table.Tr>
                    ))}
                  </Table.Tbody>
                </Table>
              </Box>
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );
}
