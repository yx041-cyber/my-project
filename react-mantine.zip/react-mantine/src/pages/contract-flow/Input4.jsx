import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useContractFlow } from '../../context/ContractFlowContext';
import FlowLayout from './FlowLayout';
import ArrowStepper from './ArrowStepper';
import { Box, Title, Text, Button, Table } from '@mantine/core';

export default function Input4() {
  const navigate = useNavigate();
  const { user, addContract, tc } = useApp();
  const { flowState, resetFlow } = useContractFlow();
  const [registered, setRegistered] = useState(false);

  useEffect(() => {
    if (!user) { navigate('/login', { replace: true }); return; }
    const register = async () => {
      if (registered) return;
      setRegistered(true);
      const { customerInfo, selectedProduct, selectedSubProduct, estimate, hasOtherContract } = flowState;
      await addContract({
        customerName: customerInfo.name, customerBirthday: customerInfo.birthday,
        customerGender: customerInfo.gender, customerAddress: customerInfo.address,
        customerPhone: customerInfo.phone, customerEmail: customerInfo.email,
        productName: selectedProduct?.name, subProductName: selectedSubProduct?.name,
        monthlyFee: estimate?.total, hasOtherContract,
      });
    };
    register();
  }, [user, navigate, flowState, addContract, registered]);

  if (!user) return null;

  return (
    <FlowLayout title="契約完了" hideActions>
      <ArrowStepper activeIndex={3} primaryColor={tc.primary} />
      <Box ta="center" py={32}>
        <Text fz={48} mb={12}>✅</Text>
        <Title order={3} c="green.6" mb={8}>契約が完了しました</Title>
        <Text c="dimmed" mb={24}>
          お客様の契約手続きが正常に完了しました。<br />
          契約書類は後日、登録されたメールアドレスにお送りいたします。
        </Text>

        <Box maw={500} mx="auto" mb={24} style={{ border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' }}>
          <Box bg={tc.accentLighter} px={16} py={8}>
            <Text fw={700}>契約概要</Text>
          </Box>
          <Table verticalSpacing="xs">
            <Table.Tbody>
              <Table.Tr>
                <Table.Td c="dimmed">顧客名</Table.Td>
                <Table.Td ta="right">{flowState.customerInfo.name}</Table.Td>
              </Table.Tr>
              <Table.Tr>
                <Table.Td c="dimmed">商品</Table.Td>
                <Table.Td ta="right">{flowState.selectedProduct?.name}</Table.Td>
              </Table.Tr>
              <Table.Tr>
                <Table.Td c="dimmed">プラン</Table.Td>
                <Table.Td ta="right">{flowState.selectedSubProduct?.name}</Table.Td>
              </Table.Tr>
              <Table.Tr>
                <Table.Td c="dimmed">月額（税込）</Table.Td>
                <Table.Td ta="right" fw={700} style={{ color: tc.primary }}>¥{flowState.estimate?.total?.toLocaleString()}</Table.Td>
              </Table.Tr>
            </Table.Tbody>
          </Table>
        </Box>

        <Button size="lg" style={{ backgroundColor: tc.primary, color: 'white' }}
          onClick={() => { resetFlow(); navigate('/personal', { replace: true }); }}>
          マイページへ戻る
        </Button>
      </Box>
    </FlowLayout>
  );
}
