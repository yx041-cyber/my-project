/**
 * モックAPI（テスト用）
 * API1: ログイン
 * API2: 締結済み契約一覧取得
 * API3: 商品一覧取得
 * API4: 契約登録
 * API5: 契約詳細取得
 * API6: 見積計算
 */

// ログインAPI（テスト時は入力なしでも成功）
export async function loginApi(account, password) {
  await new Promise((r) => setTimeout(r, 500));
  return {
    success: true,
    user: {
      id: 'user-001',
      name: account || '山田太郎',
      email: account ? `${account}@example.com` : 'yamada@example.com',
      role: '営業担当',
    },
  };
}

// 締結済み契約一覧API
export async function getContractsApi(userId) {
  await new Promise((r) => setTimeout(r, 400));
  return {
    success: true,
    contracts: [
      {
        id: 'contract-001',
        customerName: '佐藤花子',
        productName: '安心プラン',
        signedAt: '2024-01-15',
        duration: '1年',
        endDate: '2025-01-14',
        status: '有効',
      },
      {
        id: 'contract-002',
        customerName: '鈴木一郎',
        productName: 'スタンダードプラン',
        signedAt: '2024-02-20',
        duration: '2年',
        endDate: '2026-02-19',
        status: '有効',
      },
    ],
  };
}

// 商品一覧API
export async function getProductsApi() {
  await new Promise((r) => setTimeout(r, 300));
  return {
    success: true,
    products: [
      {
        id: 'prod-001',
        name: '安心プラン',
        icon: '🛡️',
        description: '基本的な保障をカバーする安心のプランです。',
        subProducts: [
          { id: 'sub-001-a', name: 'ライト', price: 1480, recommended: false },
          { id: 'sub-001-b', name: 'スタンダード', price: 2980, recommended: true },
          { id: 'sub-001-c', name: 'プレミアム', price: 4980, recommended: false },
        ],
      },
      {
        id: 'prod-002',
        name: '充実プラン',
        icon: '⭐',
        description: '幅広い保障内容で安心をお届けします。',
        subProducts: [
          { id: 'sub-002-a', name: 'ライト', price: 2980, recommended: false },
          { id: 'sub-002-b', name: 'スタンダード', price: 4980, recommended: true },
          { id: 'sub-002-c', name: 'プレミアム', price: 7980, recommended: false },
        ],
      },
      {
        id: 'prod-003',
        name: 'ファミリープラン',
        icon: '👨‍👩‍👧‍👦',
        description: 'ご家族全員を守る包括的なプランです。',
        subProducts: [
          { id: 'sub-003-a', name: '3人まで', price: 3980, recommended: false },
          { id: 'sub-003-b', name: '5人まで', price: 5980, recommended: true },
          { id: 'sub-003-c', name: '無制限', price: 8980, recommended: false },
        ],
      },
      {
        id: 'prod-004',
        name: 'シニアプラン',
        icon: '🏠',
        description: '60歳以上の方向けの特別プランです。',
        subProducts: [
          { id: 'sub-004-a', name: 'エコノミー', price: 1980, recommended: false },
          { id: 'sub-004-b', name: 'スタンダード', price: 2980, recommended: true },
          { id: 'sub-004-c', name: 'コンフォート', price: 4480, recommended: false },
        ],
      },
      {
        id: 'prod-005',
        name: '学生プラン',
        icon: '📚',
        description: '学生の方向けのお得なプランです。',
        subProducts: [
          { id: 'sub-005-a', name: 'ミニマム', price: 780, recommended: false },
          { id: 'sub-005-b', name: 'スタンダード', price: 1480, recommended: true },
          { id: 'sub-005-c', name: 'プラス', price: 2280, recommended: false },
        ],
      },
      {
        id: 'prod-006',
        name: 'ビジネスプラン',
        icon: '💼',
        description: 'ビジネスパーソン向けの充実プランです。',
        subProducts: [
          { id: 'sub-006-a', name: 'ベーシック', price: 3980, recommended: false },
          { id: 'sub-006-b', name: 'スタンダード', price: 5980, recommended: true },
          { id: 'sub-006-c', name: 'エグゼクティブ', price: 9800, recommended: false },
        ],
      },
      {
        id: 'prod-007',
        name: 'ペットプラン',
        icon: '🐕',
        description: '大切なペットのための保障プランです。',
        subProducts: [
          { id: 'sub-007-a', name: '小型', price: 980, recommended: false },
          { id: 'sub-007-b', name: '中・大型', price: 1980, recommended: true },
          { id: 'sub-007-c', name: '多頭飼い', price: 2980, recommended: false },
        ],
      },
      {
        id: 'prod-008',
        name: '旅行プラン',
        icon: '✈️',
        description: '旅行中のトラブルをカバーするプランです。',
        subProducts: [
          { id: 'sub-008-a', name: '国内', price: 500, recommended: false },
          { id: 'sub-008-b', name: '海外ベーシック', price: 1500, recommended: true },
          { id: 'sub-008-c', name: '海外プレミアム', price: 2800, recommended: false },
        ],
      },
    ],
  };
}

// 契約詳細取得API
export async function getContractDetailApi(contractId) {
  await new Promise((r) => setTimeout(r, 300));
  // モックデータ
  const mockDetails = {
    'contract-001': {
      id: 'contract-001',
      customerName: '佐藤花子',
      customerBirthday: '1985-03-15',
      customerGender: '女性',
      customerAddress: '東京都新宿区西新宿1-1-1',
      customerPhone: '090-1234-5678',
      customerEmail: 'sato@example.com',
      productName: '安心プラン',
      subProductName: 'スタンダード',
      signedAt: '2024-01-15',
      duration: '1年',
      endDate: '2025-01-14',
      monthlyFee: 2980,
      status: '有効',
      hasOtherContract: false,
    },
    'contract-002': {
      id: 'contract-002',
      customerName: '鈴木一郎',
      customerBirthday: '1978-07-22',
      customerGender: '男性',
      customerAddress: '大阪府大阪市中央区本町2-2-2',
      customerPhone: '080-9876-5432',
      customerEmail: 'suzuki@example.com',
      productName: 'スタンダードプラン',
      subProductName: 'プレミアム',
      signedAt: '2024-02-20',
      duration: '2年',
      endDate: '2026-02-19',
      monthlyFee: 5980,
      status: '有効',
      hasOtherContract: true,
    },
  };
  return {
    success: true,
    contract: mockDetails[contractId] || null,
  };
}

// 見積計算API
export async function calculateEstimateApi(birthday, gender, productId, subProductId) {
  await new Promise((r) => setTimeout(r, 200));
  
  const basePrice = 2000;
  const ageModifier = birthday ? 1.0 : 1.0;
  const genderModifier = gender === '男性' ? 1.1 : 1.0;
  const monthlyFee = Math.round(basePrice * ageModifier * genderModifier);
  return {
    success: true,
    estimate: {
      monthlyFee,
      annualFee: monthlyFee * 12,
      tax: Math.round(monthlyFee * 0.1),
      total: Math.round(monthlyFee * 1.1),
    },
  };
}

// 契約登録API
export async function registerContractApi(contractData) {
  await new Promise((r) => setTimeout(r, 500));
  const newContract = {
    id: `contract-${Date.now()}`,
    customerName: contractData.customerName,
    productName: contractData.productName,
    subProductName: contractData.subProductName,
    signedAt: new Date().toISOString().slice(0, 10),
    duration: '1年',
    endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    monthlyFee: contractData.monthlyFee,
    status: '有効',
    ...contractData,
  };
  return {
    success: true,
    contract: newContract,
  };
}
