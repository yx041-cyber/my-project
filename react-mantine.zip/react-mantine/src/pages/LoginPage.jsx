import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Box, Flex, Title, Text, TextInput, PasswordInput, Button, Stack, Loader } from '@mantine/core';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, loading } = useApp();
  const [account, setAccount] = useState('');
  const [password, setPassword] = useState('');
  const [deptCode, setDeptCode] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    const ok = await login(account, password, deptCode);
    if (ok) navigate('/personal', { replace: true });
  };

  return (
    <Flex direction="column" mih="100vh" bg="#f2f2f2">
      {/* ヘッダー */}
      <Flex bg="#1a1a2e" px={24} py={12} justify="space-between" align="center">
        <Title order={4} c="white">契約管理システム</Title>
        <Text size="sm" c="white">営業担当者向け</Text>
      </Flex>

      {/* メイン */}
      <Flex flex={1} align="center" justify="center" p="md">
        <Box w="100%" maw={440} bg="white" style={{ borderRadius: 12, boxShadow: '0 10px 15px -3px rgba(0,0,0,.1)', overflow: 'hidden' }}>
          <Box bg="#dbeafe" py="md" px={20} style={{ borderBottom: '1px solid #e5e7eb' }}>
            <Title order={4} ta="center">ログイン</Title>
          </Box>
          <form onSubmit={handleLogin} style={{ padding: 24 }}>
            <Stack gap="md">
              <TextInput
                label="アカウント（ID）"
                value={account}
                onChange={(e) => setAccount(e.currentTarget.value)}
                placeholder="アカウントを入力"
              />
              <PasswordInput
                label="パスワード"
                value={password}
                onChange={(e) => setPassword(e.currentTarget.value)}
                placeholder="パスワードを入力"
              />
              <Box>
                <TextInput
                  label="部門コード"
                  value={deptCode}
                  onChange={(e) => setDeptCode(e.currentTarget.value)}
                  placeholder="例：111, 222, 333"
                />
                <Text size="xs" c="dimmed" mt={4}>部門コードにより画面テーマが変わります</Text>
              </Box>
              <Button
                type="submit"
                w="80%"
                size="lg"
                style={{ backgroundColor: '#dbeafe', color: '#111', margin: '0 auto', display: 'block' }}
                disabled={loading}
              >
                {loading ? <Loader size="sm" /> : 'ログイン'}
              </Button>
            </Stack>
            <Text size="xs" c="dimmed" ta="center" mt="md">
              ※テスト時は入力なしでログインできます。
            </Text>
          </form>
        </Box>
      </Flex>

      {/* フッター */}
      <Flex bg="#1a1a2e" px={24} py={8} justify="space-between" align="center">
        <Text size="sm" fw={700} c="white">契約管理システム</Text>
        <Text size="xs" c="white">© 契約管理サービス　お問い合わせはサポートまで</Text>
      </Flex>
    </Flex>
  );
}
