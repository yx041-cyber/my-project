import { createContext, useContext, useState, useCallback } from 'react';

const ContractFlowContext = createContext(null);

const initialFlowState = {
  step: 1, // 1:見積, 2:顧客情報, 3:契約状況, 4:最終確認, 5:完了
  selectedProduct: null,
  selectedSubProduct: null,
  recommendedProducts: [],
  estimate: null,
  customerInfo: {
    name: '',
    gender: '',
    birthday: '',
    address: '',
    phone: '',
    email: '',
  },
  contractStartDate: '',
  confirmedTerms: false,
  confirmedImportantMatters: false,
  hasOtherContract: null,
  confirmedPersonalInfo: false,
  confirmedContractInfo: false,
};

export function ContractFlowProvider({ children }) {
  const [flowState, setFlowState] = useState(initialFlowState);

  const setStep = useCallback((step) => {
    setFlowState((prev) => ({ ...prev, step }));
  }, []);

  const setSelectedProduct = useCallback((product) => {
    setFlowState((prev) => ({ ...prev, selectedProduct: product, selectedSubProduct: null }));
  }, []);

  const setSelectedSubProduct = useCallback((subProduct) => {
    setFlowState((prev) => ({ ...prev, selectedSubProduct: subProduct }));
  }, []);

  const setRecommendedProducts = useCallback((products) => {
    setFlowState((prev) => ({ ...prev, recommendedProducts: products }));
  }, []);

  const setEstimate = useCallback((estimate) => {
    setFlowState((prev) => ({ ...prev, estimate }));
  }, []);

  const setCustomerInfo = useCallback((info) => {
    setFlowState((prev) => ({
      ...prev,
      customerInfo: { ...prev.customerInfo, ...info },
    }));
  }, []);

  const setConfirmedTerms = useCallback((confirmed) => {
    setFlowState((prev) => ({ ...prev, confirmedTerms: confirmed }));
  }, []);

  const setConfirmedImportantMatters = useCallback((confirmed) => {
    setFlowState((prev) => ({ ...prev, confirmedImportantMatters: confirmed }));
  }, []);

  const setHasOtherContract = useCallback((has) => {
    setFlowState((prev) => ({ ...prev, hasOtherContract: has }));
  }, []);

  const setConfirmedPersonalInfo = useCallback((confirmed) => {
    setFlowState((prev) => ({ ...prev, confirmedPersonalInfo: confirmed }));
  }, []);

  const setConfirmedContractInfo = useCallback((confirmed) => {
    setFlowState((prev) => ({ ...prev, confirmedContractInfo: confirmed }));
  }, []);

  const setContractStartDate = useCallback((date) => {
    setFlowState((prev) => ({ ...prev, contractStartDate: date }));
  }, []);

  const resetFlow = useCallback(() => {
    setFlowState(initialFlowState);
  }, []);

  const goToNextStep = useCallback(() => {
    setFlowState((prev) => ({ ...prev, step: prev.step + 1 }));
  }, []);

  const goToPrevStep = useCallback(() => {
    setFlowState((prev) => ({ ...prev, step: Math.max(1, prev.step - 1) }));
  }, []);

  return (
    <ContractFlowContext.Provider
      value={{
        flowState,
        setStep,
        setSelectedProduct,
        setSelectedSubProduct,
        setRecommendedProducts,
        setEstimate,
        setCustomerInfo,
        setConfirmedTerms,
        setConfirmedImportantMatters,
        setHasOtherContract,
        setConfirmedPersonalInfo,
        setConfirmedContractInfo,
        setContractStartDate,
        resetFlow,
        goToNextStep,
        goToPrevStep,
      }}
    >
      {children}
    </ContractFlowContext.Provider>
  );
}

export function useContractFlow() {
  const ctx = useContext(ContractFlowContext);
  if (!ctx) throw new Error('useContractFlow must be used within ContractFlowProvider');
  return ctx;
}
