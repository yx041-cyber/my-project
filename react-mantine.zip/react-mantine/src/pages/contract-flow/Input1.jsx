import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useContractFlow } from '../../context/ContractFlowContext';
import FlowLayout from './FlowLayout';
import ArrowStepper from './ArrowStepper';
import {
  Box, Flex, Title, Text, SimpleGrid, Table, Badge,
  NativeSelect, TextInput, Grid, Checkbox, List, Button,
} from '@mantine/core';

const SECTIONS = [
  { id: 'customer', label: '顧客情報' },
  { id: 'startDate', label: '契約開始日' },
  { id: 'agreement', label: '同意事項' },
  { id: 'important', label: '重要事項' },
  { id: 'plan', label: 'プラン選択' },
];

function getAgeFromDateString(dateStr) {
  if (!dateStr) return null;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return null;
  const [y, m, d] = parts.map(Number);
  if (!y || !m || !d) return null;
  const today = new Date();
  let age = today.getFullYear() - y;
  const monthDiff = today.getMonth() + 1 - m;
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < d)) age--;
  return age;
}

function getAgeModifier(age) {
  if (age === null) return 1.0;
  if (age < 30) return 0.85;
  if (age < 40) return 1.0;
  if (age < 50) return 1.15;
  if (age < 60) return 1.3;
  return 1.5;
}

const TERMS_SECTIONS = [
  ['1. 契約の成立について', '本契約は、お客様が申込書に必要事項を記入し、当社がこれを承諾した時点で成立します。契約成立後、当社より契約書類をお送りいたします。'],
  ['2. 契約期間について', '契約期間は契約開始日から1年間です。期間満了の1ヶ月前までに解約のお申し出がない場合、自動的に1年間更新されます。'],
  ['3. 料金のお支払いについて', '月額料金は、毎月1日に当月分を口座振替またはクレジットカードにてお支払いいただきます。初回のお支払いは契約開始日となります。'],
  ['4. 解約について', '解約をご希望の場合は、解約希望日の1ヶ月前までにお申し出ください。中途解約の場合でも、既にお支払いいただいた料金の返金はいたしかねます。'],
  ['5. 個人情報の取り扱いについて', 'お客様の個人情報は、当社のプライバシーポリシーに従い、契約の履行およびサービス向上のために利用させていただきます。'],
];

const IMPORTANT_ITEMS = [
  '契約の内容について理解しました',
  '解約条件について理解しました',
  '料金の支払い方法について理解しました',
  '個人情報の取り扱いについて同意します',
  'クーリングオフについて理解しました',
];

export default function Input1() {
  const navigate = useNavigate();
  const { user, tc } = useApp();
  const {
    flowState, setSelectedSubProduct, setEstimate, setCustomerInfo,
    setConfirmedTerms, setConfirmedImportantMatters, setContractStartDate,
  } = useContractFlow();

  const product = flowState.selectedProduct;
  const subProducts = product?.subProducts || [];
  const recommendedSub = subProducts.find((s) => s.recommended) || subProducts[0];

  // --- プラン選択 ---
  const [selectedSubId, setSelectedSubId] = useState(
    flowState.selectedSubProduct?.id || recommendedSub?.id || ''
  );

  // --- 顧客情報 ---
  const [name, setName] = useState(flowState.customerInfo.name || '');
  const [gender, setGender] = useState(flowState.customerInfo.gender || '');
  const [birthday, setBirthday] = useState(flowState.customerInfo.birthday || '');
  const [address, setAddress] = useState(flowState.customerInfo.address || '');
  const [phone, setPhone] = useState(flowState.customerInfo.phone || '');
  const [email, setEmail] = useState(flowState.customerInfo.email || '');

  // --- 契約開始日 ---
  const [startDate, setStartDate] = useState(flowState.contractStartDate || '');

  // --- 同意事項 ---
  const [agreedTerms, setAgreedTerms] = useState(false);

  // --- 重要事項 ---
  const [readDocument, setReadDocument] = useState(false);
  const [confirmedImportant, setConfirmedImportant] = useState(false);

  // --- セクションナビ ---
  const [activeSection, setActiveSection] = useState('customer');
  const sectionRefs = useRef({});

  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);

  useEffect(() => {
    if (!flowState.selectedSubProduct && recommendedSub) {
      setSelectedSubProduct(recommendedSub);
      setSelectedSubId(recommendedSub.id);
    }
  }, []);

  const selectedSub = subProducts.find((s) => s.id === selectedSubId) || null;
  const age = getAgeFromDateString(birthday);
  const ageModifier = getAgeModifier(age);

  const localEstimate = useMemo(() => {
    if (!selectedSub) return null;
    const monthlyFee = Math.round(selectedSub.price * ageModifier);
    const tax = Math.round(monthlyFee * 0.1);
    return { monthlyFee, annualFee: monthlyFee * 12, tax, total: monthlyFee + tax };
  }, [selectedSub, ageModifier]);

  useEffect(() => {
    if (localEstimate) setEstimate(localEstimate);
  }, [localEstimate, setEstimate]);

  const scrollToSection = useCallback((id) => {
    setActiveSection(id);
    sectionRefs.current[id]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  const handleSubSelect = (subId) => {
    setSelectedSubId(subId);
    const sub = subProducts.find((s) => s.id === subId);
    if (sub) setSelectedSubProduct(sub);
  };

  const emptyBg = (v) => v ? 'white' : '#dcfce7';

  const handleNext = () => {
    setCustomerInfo({ name, gender, birthday, address, phone, email });
    setContractStartDate(startDate);
    setConfirmedTerms(true);
    setConfirmedImportantMatters(true);
    navigate('/contract-flow/input-3');
  };

  const handleOpenPdf = () => {
    window.open('/important-matters.html', '_blank');
    setReadDocument(true);
  };

  if (!user) return null;

  const canProceed = name && gender && birthday && address && phone && email
    && startDate && agreedTerms && readDocument && confirmedImportant && selectedSub;

  /* ========== 見積りパネル（PC左サイドバー / SP下部 共通） ========== */
  const estimatePanel = (
    <Box p="sm" style={{ border: `1px solid ${tc.primary}40`, borderRadius: 8, backgroundColor: tc.accentLighter }}>
      <Text size="xs" fw={700} mb={8} px={4} style={{ color: tc.primary }}>見積り金額</Text>
      {localEstimate ? (
        <Box style={{ borderRadius: 6, overflow: 'hidden', border: '1px solid #e5e7eb', backgroundColor: 'white' }}>
          <Table verticalSpacing={4} fz="xs">
            <Table.Tbody>
              <Table.Tr>
                <Table.Td py={6} px={8}>{product?.name}（{selectedSub?.name}）</Table.Td>
                <Table.Td py={6} px={8} ta="right">¥{selectedSub?.price.toLocaleString()}/月</Table.Td>
              </Table.Tr>
              {age !== null && (
                <Table.Tr>
                  <Table.Td py={6} px={8}>年齢係数 ×{ageModifier.toFixed(2)}</Table.Td>
                  <Table.Td py={6} px={8} ta="right">¥{localEstimate.monthlyFee.toLocaleString()}/月</Table.Td>
                </Table.Tr>
              )}
              <Table.Tr>
                <Table.Td py={6} px={8}>消費税</Table.Td>
                <Table.Td py={6} px={8} ta="right">¥{localEstimate.tax.toLocaleString()}</Table.Td>
              </Table.Tr>
              <Table.Tr>
                <Table.Td py={8} px={8} fw={700}>月額合計（税込）</Table.Td>
                <Table.Td py={8} px={8} ta="right" fw={700} fz="sm" style={{ color: tc.primary }}>
                  ¥{localEstimate.total.toLocaleString()}
                </Table.Td>
              </Table.Tr>
            </Table.Tbody>
          </Table>
        </Box>
      ) : (
        <Text size="xs" c="dimmed" px={4}>プランを選択すると表示されます</Text>
      )}
    </Box>
  );

  /* ========== 目次ナビ（PC縦型） ========== */
  const verticalNav = (
    <Box p="xs" style={{ border: '1px solid #e5e7eb', borderRadius: 8, backgroundColor: '#f9fafb' }}>
      <Text size="xs" fw={700} c="dimmed" mb={8} px={8}>目次</Text>
      {SECTIONS.map(({ id, label }) => (
        <Box key={id} px={12} py={8} mb={2}
          style={{
            borderRadius: 6, cursor: 'pointer',
            backgroundColor: activeSection === id ? `${tc.primary}15` : 'transparent',
            borderLeft: activeSection === id ? `3px solid ${tc.primary}` : '3px solid transparent',
            transition: 'all 0.2s',
          }}
          onClick={() => scrollToSection(id)}>
          <Text size="sm" fw={activeSection === id ? 700 : 400}
            c={activeSection === id ? tc.primary : '#6b7280'}
            style={{ transition: 'all 0.2s' }}>
            {label}
          </Text>
        </Box>
      ))}
    </Box>
  );

  /* ========== 目次ナビ（SP横型） ========== */
  const horizontalNav = (
    <Flex gap={6} mb="md" style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
      {SECTIONS.map(({ id, label }) => (
        <Box key={id} px={12} py={6}
          style={{
            borderRadius: 20, cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0,
            backgroundColor: activeSection === id ? tc.primary : '#f1f5f9',
            transition: 'all 0.2s',
          }}
          onClick={() => scrollToSection(id)}>
          <Text size="xs" fw={activeSection === id ? 700 : 500}
            style={{ color: activeSection === id ? 'white' : '#6b7280' }}>
            {label}
          </Text>
        </Box>
      ))}
    </Flex>
  );

  /* ========== 各セクションで共通のスタイル ========== */
  const sectionStyle = { scrollMarginTop: 80, border: '1px solid #d1d5db', borderRadius: 12, cursor: 'default' };

  return (
    <FlowLayout title="情報入力" onBack={() => navigate('/contract-flow/product-intro')} onNext={handleNext} nextDisabled={!canProceed}>
      <ArrowStepper activeIndex={1} primaryColor={tc.primary} />

      {product && (
        <Flex align="center" gap="sm" mb={16} p={12}
          style={{ backgroundColor: tc.accentLighter, borderRadius: 8, border: `1px solid ${tc.primary}30` }}>
          <Text fz={28}>{product.icon}</Text>
          <Box>
            <Text fw={700}>{product.name}</Text>
            <Text size="xs" c="dimmed">{product.description}</Text>
          </Box>
        </Flex>
      )}

      <Text size="sm" c="dimmed" mb="md">
        ※ 未入力の項目は緑色で表示されます。すべての項目を入力し、確認事項にチェックを入れてください。
      </Text>

      {/* SP: 横型ナビを最上部に表示 */}
      <Box hiddenFrom="sm">{horizontalNav}</Box>

      <Flex gap="lg">
        {/* PC: 左サイドバー（見積り + 目次） */}
        <Box w={220} miw={200} visibleFrom="sm"
          style={{ position: 'sticky', top: 80, alignSelf: 'flex-start', flexShrink: 0 }}>
          <Box mb="sm">{estimatePanel}</Box>
          {verticalNav}
        </Box>

        {/* メインコンテンツ */}
        <Box flex={1} miw={0}>

          {/* ===== 1. 顧客情報 ===== */}
          <Box ref={(el) => { sectionRefs.current.customer = el; }} mb={20} p={20}
            onClick={() => setActiveSection('customer')} style={sectionStyle}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              顧客情報
            </Title>
            <Grid>
              <Grid.Col span={{ base: 12, sm: 6 }}>
                <TextInput label={<>お名前 <Text span c="red">*</Text></>}
                  value={name} onChange={(e) => setName(e.currentTarget.value)}
                  placeholder="例：山田 太郎" styles={{ input: { backgroundColor: emptyBg(name) } }} />
              </Grid.Col>
              <Grid.Col span={{ base: 12, sm: 6 }}>
                <NativeSelect label={<>性別 <Text span c="red">*</Text></>}
                  data={[{ value: '', label: '選択してください' }, { value: '男性', label: '男性' }, { value: '女性', label: '女性' }]}
                  value={gender} onChange={(e) => setGender(e.currentTarget.value)}
                  styles={{ input: { backgroundColor: emptyBg(gender) } }} />
              </Grid.Col>
              <Grid.Col span={{ base: 12, sm: 6 }}>
                <TextInput label={<>生年月日 <Text span c="red">*</Text></>}
                  type="date" value={birthday} onChange={(e) => setBirthday(e.currentTarget.value)}
                  styles={{ input: { backgroundColor: emptyBg(birthday) } }} />
              </Grid.Col>
              <Grid.Col span={{ base: 12, sm: 6 }}>
                <TextInput label={<>電話番号 <Text span c="red">*</Text></>}
                  value={phone} onChange={(e) => setPhone(e.currentTarget.value)}
                  placeholder="例：090-1234-5678" styles={{ input: { backgroundColor: emptyBg(phone) } }} />
              </Grid.Col>
              <Grid.Col span={12}>
                <TextInput label={<>住所 <Text span c="red">*</Text></>}
                  value={address} onChange={(e) => setAddress(e.currentTarget.value)}
                  placeholder="例：東京都新宿区西新宿1-1-1" styles={{ input: { backgroundColor: emptyBg(address) } }} />
              </Grid.Col>
              <Grid.Col span={12}>
                <TextInput label={<>メールアドレス <Text span c="red">*</Text></>}
                  type="email" value={email} onChange={(e) => setEmail(e.currentTarget.value)}
                  placeholder="例：yamada@example.com" styles={{ input: { backgroundColor: emptyBg(email) } }} />
              </Grid.Col>
            </Grid>
            {age !== null && (
              <Text size="sm" c="dimmed" mt={12}>年齢：{age}歳（料金係数：×{ageModifier.toFixed(2)}）</Text>
            )}
          </Box>

          {/* ===== 2. 契約開始日 ===== */}
          <Box ref={(el) => { sectionRefs.current.startDate = el; }} mb={20} p={20}
            onClick={() => setActiveSection('startDate')} style={sectionStyle}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              契約開始日
            </Title>
            <Text size="sm" c="dimmed" mb={12}>ご希望の契約開始日を選択してください。</Text>
            <TextInput label={<>契約開始日 <Text span c="red">*</Text></>}
              type="date" value={startDate} onChange={(e) => setStartDate(e.currentTarget.value)}
              maw={300} styles={{ input: { backgroundColor: emptyBg(startDate) } }} />
          </Box>

          {/* ===== 3. 同意事項 ===== */}
          <Box ref={(el) => { sectionRefs.current.agreement = el; }} mb={20} p={20}
            onClick={() => setActiveSection('agreement')} style={sectionStyle}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              同意事項
            </Title>
            <Text c="dimmed" mb="md">以下の内容をお読みいただき、ご同意のうえ次へお進みください。</Text>
            <Box bg="#f9fafb" p={20} mb="md" style={{ borderRadius: 8 }}>
              {TERMS_SECTIONS.map(([title, body]) => (
                <Box key={title} mb="md">
                  <Title order={5} mb={4}>{title}</Title>
                  <Text size="sm" c="dimmed" lh={1.7}>{body}</Text>
                </Box>
              ))}
            </Box>
            <Box p={12} mb="md" style={{ backgroundColor: '#fff7ed', border: '1px solid #fb923c', borderRadius: 6 }}>
              <Text size="sm" style={{ color: '#9a3412' }}>
                <strong>ご注意：</strong>上記内容をよくお読みになり、ご理解いただいたうえでチェックボックスにチェックを入れてください。
              </Text>
            </Box>
            <Checkbox label="上記の確認事項を読み、内容に同意します"
              checked={agreedTerms} onChange={(e) => setAgreedTerms(e.currentTarget.checked)} />
          </Box>

          {/* ===== 4. 重要事項 ===== */}
          <Box ref={(el) => { sectionRefs.current.important = el; }} mb={20} p={20}
            onClick={() => setActiveSection('important')} style={sectionStyle}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              重要事項
            </Title>
            <Text c="dimmed" mb="md">
              契約に関する重要事項をまとめた書類です。必ずお読みいただき、確認チェックを入れてください。
            </Text>
            <Flex align="center" gap="sm" mb={20} wrap="wrap">
              <Button variant="outline" onClick={handleOpenPdf} size="lg">重要事項説明書を開く（PDF）</Button>
              {readDocument && <Badge color="green" size="lg">閲覧済み</Badge>}
            </Flex>
            <Box bg="#f9fafb" p="md" mb="md" style={{ borderRadius: 8 }}>
              <Text fw={600} mb={8}>確認内容</Text>
              <List spacing="xs">
                {IMPORTANT_ITEMS.map((text) => (
                  <List.Item key={text}>{text}</List.Item>
                ))}
              </List>
            </Box>
            {!readDocument && (
              <Box p={12} mb="md" style={{ backgroundColor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 6 }}>
                <Text size="sm" style={{ color: '#1d4ed8' }}>先に説明書をお読みください。</Text>
              </Box>
            )}
            <Checkbox label="重要事項説明書を読み、上記の内容を確認しました"
              checked={confirmedImportant} onChange={(e) => setConfirmedImportant(e.currentTarget.checked)}
              disabled={!readDocument} />
          </Box>

          {/* ===== 5. プラン選択 ===== */}
          <Box ref={(el) => { sectionRefs.current.plan = el; }} mb={20} p={20}
            onClick={() => setActiveSection('plan')} style={sectionStyle}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              プラン選択
            </Title>
            <SimpleGrid cols={{ base: 1, xs: 2, sm: 3 }} spacing="md">
              {subProducts.map((sub) => {
                const isSelected = selectedSubId === sub.id;
                const isRecommended = sub.recommended;
                return (
                  <Box key={sub.id} p={16} ta="center" pos="relative" className="card-hover"
                    style={{
                      border: `2px solid ${isSelected ? tc.primary : '#e5e7eb'}`,
                      backgroundColor: isSelected ? tc.accentLighter : 'white',
                      borderRadius: 12, cursor: 'pointer', transition: 'all 0.2s',
                    }}
                    onClick={() => handleSubSelect(sub.id)}>
                    {isRecommended && (
                      <Badge pos="absolute" top={-10} left="50%" size="sm"
                        style={{ backgroundColor: tc.primary, color: 'white', transform: 'translateX(-50%)' }}>
                        おすすめ
                      </Badge>
                    )}
                    <Text fw={700} mt={isRecommended ? 4 : 0}>{sub.name}</Text>
                    <Text fz={22} fw={700} mt={8} style={{ color: tc.primary }}>
                      ¥{sub.price.toLocaleString()}
                      <Text span fz={12} fw={400} c="dimmed">/月</Text>
                    </Text>
                    {isSelected && (
                      <Badge mt={8} variant="light" color={tc.primary} size="sm">選択中</Badge>
                    )}
                  </Box>
                );
              })}
            </SimpleGrid>
          </Box>

          {/* SP: 見積りパネルをプラン選択の下に表示 */}
          <Box hiddenFrom="sm">{estimatePanel}</Box>

        </Box>
      </Flex>
    </FlowLayout>
  );
}
