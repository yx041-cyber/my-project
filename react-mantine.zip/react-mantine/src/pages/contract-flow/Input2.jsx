import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useContractFlow } from '../../context/ContractFlowContext';
import FlowLayout from './FlowLayout';
import ArrowStepper from './ArrowStepper';
import { Box, Flex, Text, TextInput, Grid, NativeSelect, Checkbox, Title, List, Button, Badge } from '@mantine/core';

const SECTIONS = [
  { id: 'customer', label: '顧客情報' },
  { id: 'startDate', label: '契約開始日' },
  { id: 'agreement', label: '同意事項' },
  { id: 'important', label: '重要事項' },
];

export default function Input2() {
  const navigate = useNavigate();
  const { user, tc } = useApp();
  const { flowState, setCustomerInfo, setConfirmedTerms, setConfirmedImportantMatters, setContractStartDate } = useContractFlow();

  // --- Area 1: Customer Info ---
  const [name, setName] = useState(flowState.customerInfo.name || '');
  const [gender, setGender] = useState(flowState.customerInfo.gender || '');
  const [birthday, setBirthday] = useState(flowState.customerInfo.birthday || '');
  const [address, setAddress] = useState(flowState.customerInfo.address || '');
  const [phone, setPhone] = useState(flowState.customerInfo.phone || '');
  const [email, setEmail] = useState(flowState.customerInfo.email || '');

  // --- Area 2: Contract Start Date ---
  const [startDate, setStartDate] = useState(flowState.contractStartDate || '');

  // --- Area 3: Agreement ---
  const [agreedTerms, setAgreedTerms] = useState(false);

  // --- Area 4: Important Matters ---
  const [readDocument, setReadDocument] = useState(false);
  const [confirmedImportant, setConfirmedImportant] = useState(false);

  // --- Active section tracking ---
  const [activeSection, setActiveSection] = useState('customer');
  const sectionRefs = useRef({});

  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);

  const scrollToSection = useCallback((id) => {
    setActiveSection(id);
    sectionRefs.current[id]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  const emptyBg = (v) => v ? 'white' : '#dcfce7';

  const handleNext = () => {
    setCustomerInfo({ name, gender, birthday, address, phone, email });
    setContractStartDate(startDate);
    setConfirmedTerms(true);
    setConfirmedImportantMatters(true);
    navigate('/contract-flow/input-3');
  };

  const canProceed = name && gender && birthday && address && phone && email
    && startDate && agreedTerms && readDocument && confirmedImportant;

  const handleOpenPdf = () => {
    window.open('/important-matters.html', '_blank');
    setReadDocument(true);
  };

  if (!user) return null;

  const termsSections = [
    ['1. 契約の成立について', '本契約は、お客様が申込書に必要事項を記入し、当社がこれを承諾した時点で成立します。契約成立後、当社より契約書類をお送りいたします。'],
    ['2. 契約期間について', '契約期間は契約開始日から1年間です。期間満了の1ヶ月前までに解約のお申し出がない場合、自動的に1年間更新されます。'],
    ['3. 料金のお支払いについて', '月額料金は、毎月1日に当月分を口座振替またはクレジットカードにてお支払いいただきます。初回のお支払いは契約開始日となります。'],
    ['4. 解約について', '解約をご希望の場合は、解約希望日の1ヶ月前までにお申し出ください。中途解約の場合でも、既にお支払いいただいた料金の返金はいたしかねます。'],
    ['5. 個人情報の取り扱いについて', 'お客様の個人情報は、当社のプライバシーポリシーに従い、契約の履行およびサービス向上のために利用させていただきます。'],
  ];

  const importantItems = [
    '契約の内容について理解しました',
    '解約条件について理解しました',
    '料金の支払い方法について理解しました',
    '個人情報の取り扱いについて同意します',
    'クーリングオフについて理解しました',
  ];

  return (
    <FlowLayout title="顧客情報入力" onBack={() => navigate('/contract-flow/input-1')} onNext={handleNext} nextDisabled={!canProceed}>
      <ArrowStepper activeIndex={2} primaryColor={tc.primary} />
      <Text size="sm" c="dimmed" mb="md">※ 未入力の項目は緑色で表示されます。すべての項目を入力し、確認事項にチェックを入れてください。</Text>

      <Flex gap="lg">
        {/* Side Navigation */}
        <Box w={160} miw={140} display={{ base: 'none', sm: 'block' }}
          style={{ position: 'sticky', top: 80, alignSelf: 'flex-start', flexShrink: 0 }}>
          <Box p="xs" style={{ border: '1px solid #e5e7eb', borderRadius: 8, backgroundColor: '#f9fafb' }}>
            <Text size="xs" fw={700} c="dimmed" mb={8} px={8}>目次</Text>
            {SECTIONS.map(({ id, label }) => (
              <Box
                key={id}
                px={12}
                py={8}
                mb={2}
                style={{
                  borderRadius: 6,
                  cursor: 'pointer',
                  backgroundColor: activeSection === id ? `${tc.primary}15` : 'transparent',
                  borderLeft: activeSection === id ? `3px solid ${tc.primary}` : '3px solid transparent',
                  transition: 'all 0.2s',
                }}
                onClick={() => scrollToSection(id)}
              >
                <Text size="sm" fw={activeSection === id ? 700 : 400}
                  c={activeSection === id ? tc.primary : '#6b7280'}
                  style={{ transition: 'all 0.2s' }}>
                  {label}
                </Text>
              </Box>
            ))}
          </Box>
        </Box>

        {/* Main Content */}
        <Box flex={1} miw={0}>
          {/* Area 1: Customer Info */}
          <Box data-section="customer" ref={(el) => { sectionRefs.current.customer = el; }} mb={20} p={20}
            onClick={() => setActiveSection('customer')}
            style={{ scrollMarginTop: 80, border: '1px solid #d1d5db', borderRadius: 12, cursor: 'default' }}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              顧客情報
            </Title>
            <Grid>
              <Grid.Col span={6}>
                <TextInput
                  label={<>お名前 <Text span c="red">*</Text></>}
                  value={name}
                  onChange={(e) => setName(e.currentTarget.value)}
                  placeholder="例：山田 太郎"
                  styles={{ input: { backgroundColor: emptyBg(name) } }}
                />
              </Grid.Col>
              <Grid.Col span={6}>
                <NativeSelect
                  label={<>性別 <Text span c="red">*</Text></>}
                  data={[{ value: '', label: '選択してください' }, { value: '男性', label: '男性' }, { value: '女性', label: '女性' }]}
                  value={gender}
                  onChange={(e) => setGender(e.currentTarget.value)}
                  styles={{ input: { backgroundColor: emptyBg(gender) } }}
                />
              </Grid.Col>
              <Grid.Col span={6}>
                <TextInput
                  label={<>生年月日 <Text span c="red">*</Text></>}
                  type="date"
                  value={birthday}
                  onChange={(e) => setBirthday(e.currentTarget.value)}
                  styles={{ input: { backgroundColor: emptyBg(birthday) } }}
                />
              </Grid.Col>
              <Grid.Col span={6}>
                <TextInput
                  label={<>電話番号 <Text span c="red">*</Text></>}
                  value={phone}
                  onChange={(e) => setPhone(e.currentTarget.value)}
                  placeholder="例：090-1234-5678"
                  styles={{ input: { backgroundColor: emptyBg(phone) } }}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <TextInput
                  label={<>住所 <Text span c="red">*</Text></>}
                  value={address}
                  onChange={(e) => setAddress(e.currentTarget.value)}
                  placeholder="例：東京都新宿区西新宿1-1-1"
                  styles={{ input: { backgroundColor: emptyBg(address) } }}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <TextInput
                  label={<>メールアドレス <Text span c="red">*</Text></>}
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.currentTarget.value)}
                  placeholder="例：yamada@example.com"
                  styles={{ input: { backgroundColor: emptyBg(email) } }}
                />
              </Grid.Col>
            </Grid>
          </Box>

          {/* Area 2: Contract Start Date */}
          <Box data-section="startDate" ref={(el) => { sectionRefs.current.startDate = el; }} mb={20} p={20}
            onClick={() => setActiveSection('startDate')}
            style={{ scrollMarginTop: 80, border: '1px solid #d1d5db', borderRadius: 12, cursor: 'default' }}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              契約開始日
            </Title>
            <Text size="sm" c="dimmed" mb={12}>ご希望の契約開始日を選択してください。</Text>
            <TextInput
              label={<>契約開始日 <Text span c="red">*</Text></>}
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.currentTarget.value)}
              maw={300}
              styles={{ input: { backgroundColor: emptyBg(startDate) } }}
            />
          </Box>

          {/* Area 3: Agreement */}
          <Box data-section="agreement" ref={(el) => { sectionRefs.current.agreement = el; }} mb={20} p={20}
            onClick={() => setActiveSection('agreement')}
            style={{ scrollMarginTop: 80, border: '1px solid #d1d5db', borderRadius: 12, cursor: 'default' }}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              同意事項
            </Title>
            <Text c="dimmed" mb="md">以下の内容をお読みいただき、ご同意のうえ次へお進みください。</Text>

            <Box bg="#f9fafb" p={20} mb="md" style={{ borderRadius: 8 }}>
              {termsSections.map(([title, body]) => (
                <Box key={title} mb="md">
                  <Title order={5} mb={4}>{title}</Title>
                  <Text size="sm" c="dimmed" lh={1.7}>{body}</Text>
                </Box>
              ))}
            </Box>

            <Box p={12} mb="md" style={{ backgroundColor: '#fff7ed', border: '1px solid #fb923c', borderRadius: 6 }}>
              <Text size="sm" style={{ color: '#9a3412' }}>
                <strong>ご注意：</strong>上記内容をよくお読みになり、ご理解いただいたうえでチェックボックスにチェックを入れてください。
              </Text>
            </Box>

            <Checkbox
              label="上記の確認事項を読み、内容に同意します"
              checked={agreedTerms}
              onChange={(e) => setAgreedTerms(e.currentTarget.checked)}
            />
          </Box>

          {/* Area 4: Important Matters */}
          <Box data-section="important" ref={(el) => { sectionRefs.current.important = el; }} mb={16} p={20}
            onClick={() => setActiveSection('important')}
            style={{ scrollMarginTop: 80, border: '1px solid #d1d5db', borderRadius: 12, cursor: 'default' }}>
            <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
              重要事項
            </Title>
            <Text c="dimmed" mb="md">
              契約に関する重要事項をまとめた書類です。必ずお読みいただき、確認チェックを入れてください。
            </Text>

            <Flex align="center" gap="sm" mb={20}>
              <Button variant="outline" onClick={handleOpenPdf} size="lg">重要事項説明書を開く（PDF）</Button>
              {readDocument && <Badge color="green" size="lg">閲覧済み</Badge>}
            </Flex>

            <Box bg="#f9fafb" p="md" mb="md" style={{ borderRadius: 8 }}>
              <Text fw={600} mb={8}>確認内容</Text>
              <List spacing="xs">
                {importantItems.map((text) => (
                  <List.Item key={text}>{text}</List.Item>
                ))}
              </List>
            </Box>

            {!readDocument && (
              <Box p={12} mb="md" style={{ backgroundColor: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 6 }}>
                <Text size="sm" style={{ color: '#1d4ed8' }}>先に説明書をお読みください。</Text>
              </Box>
            )}

            <Checkbox
              label="重要事項説明書を読み、上記の内容を確認しました"
              checked={confirmedImportant}
              onChange={(e) => setConfirmedImportant(e.currentTarget.checked)}
              disabled={!readDocument}
            />
          </Box>
        </Box>
      </Flex>
    </FlowLayout>
  );
}
