import { Routes, Route, Navigate } from 'react-router-dom';
import { useApp } from './context/AppContext';
import LoginPage from './pages/LoginPage';
import PersonalPage from './pages/PersonalPage';
import ContractListPage from './pages/ContractListPage';
import ContractDetailPage from './pages/ContractDetailPage';
import ProductIntro from './pages/contract-flow/ProductIntro';
import Input1 from './pages/contract-flow/Input1';
import Input3 from './pages/contract-flow/Input3';
import Input4 from './pages/contract-flow/Input4';

function PrivateRoute({ children }) {
  const { user } = useApp();
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/personal" element={<PrivateRoute><PersonalPage /></PrivateRoute>} />
      <Route path="/contracts" element={<PrivateRoute><ContractListPage /></PrivateRoute>} />
      <Route path="/contract-detail/:contractId" element={<PrivateRoute><ContractDetailPage /></PrivateRoute>} />
      <Route path="/contract-flow/product-intro" element={<PrivateRoute><ProductIntro /></PrivateRoute>} />
      <Route path="/contract-flow/input-1" element={<PrivateRoute><Input1 /></PrivateRoute>} />
      <Route path="/contract-flow/input-3" element={<PrivateRoute><Input3 /></PrivateRoute>} />
      <Route path="/contract-flow/input-4" element={<PrivateRoute><Input4 /></PrivateRoute>} />
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default App;
