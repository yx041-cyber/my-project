import { createTheme } from '@mantine/core';

/**
 * 部門コード → テーマ設定のマッピング
 * code 111: 淡い青系テーマ
 * code 222: 淡い緑系テーマ
 * code 333: 淡い紫系テーマ
 * デフォルト: グレー系テーマ
 */
export const themeConfigs = {
  '111': {
    name: '営業一課',
    primary: '#1976d2',
    primaryLight: '#42a5f5',
    headerBg: '#1565c0',
    headerText: '#ffffff',
    sidebarBg: '#e3f2fd',
    sidebarText: '#0d47a1',
    pageBg: '#f5f9ff',
    cardBg: '#ffffff',
    accentLight: '#bbdefb',
    accentLighter: '#e3f2fd',
    stepActive: '#1976d2',
  },
  '222': {
    name: '営業二課',
    primary: '#2e7d32',
    primaryLight: '#66bb6a',
    headerBg: '#1b5e20',
    headerText: '#ffffff',
    sidebarBg: '#e8f5e9',
    sidebarText: '#1b5e20',
    pageBg: '#f5fdf5',
    cardBg: '#ffffff',
    accentLight: '#c8e6c9',
    accentLighter: '#e8f5e9',
    stepActive: '#2e7d32',
  },
  '333': {
    name: '営業三課',
    primary: '#7b1fa2',
    primaryLight: '#ab47bc',
    headerBg: '#6a1b9a',
    headerText: '#ffffff',
    sidebarBg: '#f3e5f5',
    sidebarText: '#4a148c',
    pageBg: '#fdf5ff',
    cardBg: '#ffffff',
    accentLight: '#ce93d8',
    accentLighter: '#f3e5f5',
    stepActive: '#7b1fa2',
  },
  default: {
    name: 'デフォルト',
    primary: '#1976d2',
    primaryLight: '#42a5f5',
    headerBg: '#263238',
    headerText: '#ffffff',
    sidebarBg: '#eceff1',
    sidebarText: '#263238',
    pageBg: '#fafafa',
    cardBg: '#ffffff',
    accentLight: '#cfd8dc',
    accentLighter: '#eceff1',
    stepActive: '#546e7a',
  },
};

export function getThemeConfig(deptCode) {
  return themeConfigs[deptCode] || themeConfigs.default;
}

// Mantine テーマ設定
export const mantineTheme = createTheme({
  fontFamily: '"Noto Sans JP", "Hiragino Sans", "Meiryo", system-ui, sans-serif',
  headings: {
    fontFamily: '"Noto Sans JP", "Hiragino Sans", "Meiryo", system-ui, sans-serif',
  },
});
