import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useContractFlow } from '../../context/ContractFlowContext';
import FlowLayout from './FlowLayout';
import ArrowStepper from './ArrowStepper';
import { Box, Flex, Title, Text, SimpleGrid, Badge, List, ThemeIcon } from '@mantine/core';

const PRODUCT_FEATURES = {
  'prod-001': {
    highlights: ['入院・手術をしっかりカバー', '24時間サポート対応', '全国の提携病院で利用可能'],
    details: '日常生活の中で起こりうる病気やケガに対して、基本的な保障を提供するプランです。初めて保険をご検討される方にもおすすめの内容となっております。',
    benefits: ['通院保障', '入院一時金', '手術給付金', '先進医療特約'],
  },
  'prod-002': {
    highlights: ['がん・三大疾病に手厚い保障', '特約の組み合わせが自由', '無事故割引あり'],
    details: '基本保障に加え、がん・心疾患・脳血管疾患などの重大疾病もカバーする充実のプランです。万が一の際にも安心の幅広い保障内容をご提供します。',
    benefits: ['三大疾病保障', '通院・入院保障', '就業不能給付', '先進医療特約', '介護保障'],
  },
  'prod-003': {
    highlights: ['家族全員をまとめて保障', '子どもの教育費サポート', '配偶者特約あり'],
    details: 'ご家族の人数に応じた柔軟なプラン設計で、大切なご家族全員を守ります。お子様の成長に合わせた教育費サポートも充実しています。',
    benefits: ['家族全員の医療保障', '子ども特約', '配偶者特約', '教育費サポート', '家族収入保障'],
  },
  'prod-004': {
    highlights: ['60歳以上の方専用設計', '持病があっても加入可能', '介護保障が充実'],
    details: 'シニア世代の生活に寄り添った保障内容で、安心のセカンドライフをサポートします。持病をお持ちの方でも加入いただけるプランをご用意しております。',
    benefits: ['介護一時金', '認知症サポート', '骨折治療給付', '見守りサービス'],
  },
  'prod-005': {
    highlights: ['月額780円からの低価格', '学生証提示で特別割引', 'アルバイト中のケガもカバー'],
    details: '学生の方の生活を応援する、お手頃価格のプランです。通学中やアルバイト中の事故、一人暮らしのトラブルなど、学生生活をしっかりサポートします。',
    benefits: ['通学中の事故保障', 'アルバイト中の保障', '一人暮らしサポート', '自転車事故保障'],
  },
  'prod-006': {
    highlights: ['出張・通勤中の事故をカバー', '所得補償が充実', '法人契約も可能'],
    details: 'ビジネスパーソンの多忙な毎日を支える、充実の保障内容です。万が一の就業不能時にも収入を補償し、安心して仕事に集中いただけます。',
    benefits: ['就業不能保障', '所得補償', '出張中の保障', 'メンタルヘルスサポート', '人間ドック補助'],
  },
  'prod-007': {
    highlights: ['手術費用を最大90%補償', '全国の動物病院で利用可能', '予防接種費用もサポート'],
    details: '大切な家族の一員であるペットの健康を守るプランです。急な病気やケガの際の高額な治療費をサポートし、安心してペットとの生活をお楽しみいただけます。',
    benefits: ['手術費用補償', '通院費用補償', '入院費用補償', '予防接種サポート'],
  },
  'prod-008': {
    highlights: ['国内・海外旅行に対応', '航空機遅延もカバー', '携行品損害補償あり'],
    details: '旅行中に起こりうる様々なトラブルに対応するプランです。急な病気やケガの治療費はもちろん、手荷物の紛失や航空機の遅延にも対応いたします。',
    benefits: ['傷害治療費用', '疾病治療費用', '携行品損害', '航空機遅延費用', '救援者費用'],
  },
};

const DEFAULT_FEATURES = {
  highlights: ['充実した保障内容', '24時間カスタマーサポート', 'オンライン手続き対応'],
  details: 'お客様のニーズに合わせた最適なプランをご提供いたします。詳細はプラン選択後にご確認いただけます。',
  benefits: ['基本保障', 'カスタマーサポート', 'オンライン管理'],
};

export default function ProductIntro() {
  const navigate = useNavigate();
  const { user, tc } = useApp();
  const { flowState } = useContractFlow();

  const product = flowState.selectedProduct;
  const subProducts = product?.subProducts || [];
  const features = PRODUCT_FEATURES[product?.id] || DEFAULT_FEATURES;

  useEffect(() => { if (!user) navigate('/login', { replace: true }); }, [user, navigate]);
  if (!user) return null;
  if (!product) { navigate('/personal', { replace: true }); return null; }

  return (
    <FlowLayout
      title="商品紹介"
      onBack={() => navigate('/personal')}
      onNext={() => navigate('/contract-flow/input-1')}
    >
      <ArrowStepper activeIndex={0} primaryColor={tc.primary} />

      {/* 商品ヘッダー */}
      <Flex align="center" gap="md" mb={24} p={20}
        style={{ backgroundColor: tc.accentLighter, borderRadius: 12, border: `1px solid ${tc.primary}30` }}>
        <Text fz={56}>{product.icon}</Text>
        <Box>
          <Title order={2}>{product.name}</Title>
          <Text size="md" c="dimmed" mt={4}>{product.description}</Text>
        </Box>
      </Flex>

      {/* 商品の特長 */}
      <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
        この商品の特長
      </Title>
      <SimpleGrid cols={3} spacing="md" mb={24}>
        {features.highlights.map((h, i) => (
          <Box key={i} p={16} ta="center"
            style={{ border: '1px solid #e5e7eb', borderRadius: 12, backgroundColor: '#f9fafb' }}>
            <Text fz={24} mb={8}>{['🌟', '🔒', '🏥', '✨'][i] || '✨'}</Text>
            <Text fw={600} size="sm">{h}</Text>
          </Box>
        ))}
      </SimpleGrid>

      {/* 商品の詳細説明 */}
      <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
        商品について
      </Title>
      <Text size="sm" lh={1.8} mb={24} p={16}
        style={{ backgroundColor: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb' }}>
        {features.details}
      </Text>

      {/* 保障内容 */}
      <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
        主な保障内容
      </Title>
      <List spacing="sm" mb={24} pl={4}>
        {features.benefits.map((b) => (
          <List.Item key={b} icon={
            <ThemeIcon size={22} radius="xl" style={{ backgroundColor: tc.primary }}>
              <Text fz={12} c="white" fw={700}>✓</Text>
            </ThemeIcon>
          }>
            <Text size="sm">{b}</Text>
          </List.Item>
        ))}
      </List>

      {/* プラン一覧（価格比較） */}
      <Title order={4} mb={12} style={{ borderBottom: `2px solid ${tc.primary}`, paddingBottom: 6, display: 'inline-block' }}>
        プラン・料金一覧
      </Title>
      <SimpleGrid cols={3} spacing="md" mb={8}>
        {subProducts.map((sub) => {
          const isRecommended = sub.recommended;
          return (
            <Box key={sub.id} p={16} ta="center" pos="relative"
              style={{
                border: `2px solid ${isRecommended ? tc.primary : '#e5e7eb'}`,
                backgroundColor: isRecommended ? tc.accentLighter : 'white',
                borderRadius: 12,
              }}>
              {isRecommended && (
                <Badge pos="absolute" top={-10} left="50%" size="sm"
                  style={{ backgroundColor: tc.primary, color: 'white', transform: 'translateX(-50%)' }}>
                  おすすめ
                </Badge>
              )}
              <Text fw={700} mt={isRecommended ? 4 : 0}>{sub.name}</Text>
              <Text fz={22} fw={700} mt={8} style={{ color: tc.primary }}>
                ¥{sub.price.toLocaleString()}
                <Text span fz={12} fw={400} c="dimmed">/月</Text>
              </Text>
            </Box>
          );
        })}
      </SimpleGrid>
      <Text size="xs" c="dimmed" ta="right">※ 表示価格は基本月額です。年齢等により変動します。</Text>
    </FlowLayout>
  );
}
