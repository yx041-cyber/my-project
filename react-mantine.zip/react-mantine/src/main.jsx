import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { MantineProvider } from '@mantine/core';
import '@mantine/core/styles.css';
import { mantineTheme } from './theme';
import { AppProvider } from './context/AppContext';
import { ContractFlowProvider } from './context/ContractFlowContext';
import { ErrorBoundary } from './ErrorBoundary';
import App from './App.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <MantineProvider theme={mantineTheme}>
        <AppProvider>
          <ContractFlowProvider>
            <BrowserRouter>
              <App />
            </BrowserRouter>
          </ContractFlowProvider>
        </AppProvider>
      </MantineProvider>
    </ErrorBoundary>
  </StrictMode>,
);
